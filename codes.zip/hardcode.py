with open('C_traj.txt', 'r') as f:
    x = f.read()