write_site = "http://192.168.4.1/test";
% count = length(C_qs);
% for i = 1:count
%     for j = 1:3
%         response = webwrite(site_name, C_qs(i, j));
%         pause(0.1);
%     end
%     pause(0.5);
% end

for j = 1:3
response = webwrite(site_name, C_qs(1, j));
end